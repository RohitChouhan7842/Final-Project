import React from 'react'
import TaskManager from './TaskManager'
import './App.css'
const App = () => {
  return (
    <div>
   <TaskManager/>

    </div>
  )
}

export default App